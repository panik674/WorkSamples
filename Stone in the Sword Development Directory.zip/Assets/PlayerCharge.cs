using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerCharge : MonoBehaviour
{

    public PlayerStone playerStone;
    public PlayerBreath playerBreath;
    public PlayerFury playerFury;
    public PlayerHealth playerHealth; 
    public PlayerMana playerMana;
    public Animator animator;
    public TextMeshProUGUI furyText;
    public TextMeshProUGUI breathText;
    public TextMeshProUGUI manaText;
    public AudioSource SoundEffect;
   
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C) && animator.GetBool("IsShooting") == false && animator.GetBool("IsAttacking") == false && animator.GetBool("IsJumping") == false && animator.GetBool("IsFalling") == false){
            animator.SetBool("IsCharging",true);
            
            
            
    }
    }

    void StopCharging(){
        animator.SetBool("IsCharging",false);
    }

    void Charge(){
        int manaReduction = 10;
        if(playerStone.currentStone == "Fury" && playerMana.mana >= 10){
                SoundEffect.Play();
                playerFury.increaseFury(2);
                if(playerFury.dragonsFury > 20){
                    playerFury.dragonsFury = 20;
                    manaReduction = 0;
                    
                }
                
                playerMana.mana -= manaReduction;
                furyText.text = "Dragon's Fury: " + (playerFury.dragonsFury/2).ToString();

            }
            if(playerStone.currentStone == "Breath" && playerMana.mana >= 10){
                SoundEffect.Play();
                playerBreath.increaseBreath(1);
                if(playerBreath.dragonsBreath > 10){
                    playerBreath.dragonsBreath = 10;
                    manaReduction = 0;
                    
                }
                playerMana.mana -= manaReduction;
                breathText.text = "Dragon's Breath: " + playerBreath.dragonsBreath.ToString();
            }
            if(playerStone.currentStone == "Healing" && playerMana.mana >= 10){
                
                if(playerHealth.health < 5){
                    SoundEffect.Play();
                    playerHealth.heal(1);
                    playerMana.mana -= manaReduction;
                }
            }
            manaText.text = playerMana.mana.ToString() + "/100";
    }
}
