using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialHide : MonoBehaviour
{
    public bool isPaused = false;
    public Image tutorial;
    public EnemyHealth boss;

    void Start()
    {
        tutorial.enabled = false;
    }

    void Update(){
        if(Input.GetKeyDown(KeyCode.Return)){
            tutorial.enabled = false;
            Time.timeScale = 1;
            if(boss == null){
                Application.LoadLevel(Application.loadedLevel);
            }
        
        }
        if(Input.GetKeyDown(KeyCode.P) && tutorial.enabled == false){
            if(isPaused){
            Time.timeScale = 1;
            }
            else{
                Time.timeScale = 0;
            }
            isPaused = !isPaused;

    

    
    }
    
}
}
