using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStone : MonoBehaviour
{
    
    public string currentStone = "None";
    
    public void setStone(string newStone){
        currentStone = newStone;
    }
}
