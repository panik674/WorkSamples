 using System.Collections;
 using System.Collections.Generic;
 using UnityEngine;
 
 public class MusicChange : MonoBehaviour
 {
     public AudioSource icyCave;
     public AudioSource decisiveBattle;
     
     
     void OnCollisionEnter2D(Collision2D col)
     {
        if(col.gameObject.tag == "Player" && (!icyCave.isPlaying && !decisiveBattle.isPlaying)){
            icyCave.Play();
        }
        
        if(col.gameObject.tag == "Player" && icyCave.isPlaying){
        if(gameObject.tag == "BossGround"){
            icyCave.Stop();
            decisiveBattle.Play();
        }
        }
        
        if(col.gameObject.tag == "Player" && decisiveBattle.isPlaying){
        if(gameObject.tag == "Ground"){
            decisiveBattle.Stop();
            icyCave.Play();
        }
     
 
            
            

         
     }
 }
 }
 