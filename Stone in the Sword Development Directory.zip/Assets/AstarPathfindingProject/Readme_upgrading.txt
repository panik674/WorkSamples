If you have upgraded from an older version and you are suddenly seeing compiler errors.
Please read this guide: http://arongranberg.com/astar/docs/upgrading.php

If you still cannot find a solution search the forum: http://forum.arongranberg.com.
If you cannot find a solution after that, then post a question in the forum.