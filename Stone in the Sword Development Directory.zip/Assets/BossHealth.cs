using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BossHealth : MonoBehaviour
{
    public Animator animator;
    public int health;
    public Transform transform;
    public Animator playerAnimator;
    public Image tutorial;
    public Sprite image;
    private bool isDead = false;
    

    

    //void Update()
    //{
        //if(isDead){
            //Application.LoadLevel(Application.loadedLevel);
        //}
    //}
    
    public void TakeDamage(int dmg)
    {
        health -= dmg;
        if(health > 0){
        animator.SetTrigger("Hit");
        }
    
        if(health <= 0 ){
            animator.SetTrigger("Die");
        }
        }
    
    public void die(){
        Destroy(gameObject);
        tutorial.sprite = image;
        tutorial.enabled = true;
        Time.timeScale = 0;
        isDead = true;
        
        
    }
}
