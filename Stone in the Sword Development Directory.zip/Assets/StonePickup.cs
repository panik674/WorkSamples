using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StonePickup : MonoBehaviour
{

    public PlayerStone playerStone;
    public string newStone;
    public Image oldImage;
    public Sprite newImage;
    public AudioSource SoundEffect;
    private void OnTriggerEnter2D(Collider2D collision){
        if(collision.tag == "Player"){
            SoundEffect.Play();
            playerStone.setStone(newStone);
            oldImage.sprite = newImage;
            oldImage.GetComponent<Image>().color = new Color32(255,255,255,255);
            Destroy(gameObject);
        }
        
    }
}
