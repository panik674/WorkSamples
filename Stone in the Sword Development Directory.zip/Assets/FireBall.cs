using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBall : MonoBehaviour
{
    
    public float speed;
    public Rigidbody2D rb;
    public string tag;

    void Start()
    {
        rb.velocity = (transform.right * speed) / 2;
    }

    void OnTriggerEnter2D(Collider2D collider){
        if(collider.tag == tag){
        PlayerHealth player = collider.GetComponent<PlayerHealth>();
        if (player != null && collider.tag == "Player"){
            player.TakeDamage(1);
        }
        EnemyHealth enemy = collider.GetComponent<EnemyHealth>();
        if (enemy != null && (collider.tag != "Player")){
            enemy.TakeDamage(1);
        }
        Destroy(gameObject);
        }
        
    }

    public void setTag(string tagSet){
        tag = tagSet;
    }

    public void setSpeed(float speedSet){
        speed = speedSet;
    }
}
