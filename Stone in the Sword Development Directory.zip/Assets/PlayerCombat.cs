using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerCombat : MonoBehaviour
{
    public Animator animator;
    public Transform attackPoint;
    public float attackRange = 0.5f;
    public LayerMask enemyLayers;
    public PlayerFury fury;
    public TextMeshProUGUI furyText;
    public AudioSource SoundEffect;
    public bool IsAttacking;
    


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z) && animator.GetBool("IsShooting") == false && animator.GetBool("IsCharging") == false && animator.GetBool("IsJumping") == false && animator.GetBool("IsFalling") == false){
            animator.SetBool("IsAttacking",true);
            if(!IsAttacking){
                IsAttacking = true;
                SoundEffect.Play();
            }
            
        }
        
    }
    
    public void StopAttack(){
        animator.SetBool("IsAttacking",false);
        IsAttacking = false;
    }

    void OnDrawGizmosSelected(){
        if(attackPoint == null)
            return;
        
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }

    public void damageEnemy(){
        Collider2D[] hitenemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);
            foreach(Collider2D enemy in hitenemies){
                if (enemy.GetComponent<EnemyHealth>() != null){
                Debug.Log("hit");
                if(fury.dragonsFury > 0){
                    enemy.GetComponent<EnemyHealth>().TakeDamage(2);
                    fury.dragonsFury -= 1;
                    furyText.text = "Dragon's Fury: " + (fury.dragonsFury/2).ToString();
                }
                else{
                enemy.GetComponent<EnemyHealth>().TakeDamage(1);
                }
                }
            }
    }
    

}
