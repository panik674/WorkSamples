using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public Animator animator;
    public int health;
    public AudioSource SoundEffect;
    

    void Start()
    {
        
    }
    
    public void TakeDamage(int dmg)
    {
        animator.SetBool("IsHit",true);
        health -= dmg;
        if(health <= 0 ){
            animator.SetBool("IsDead",true);
            SoundEffect.Play();
        }
        }

    public void heal(int amount){
        if (health + amount > 5){
            health = 5;
        }
        else{
            health += amount;
        }
    }

    public void respawn(){
        Destroy(gameObject);
        Application.LoadLevel(Application.loadedLevel);
    }

    public void stopHit(){
        animator.SetBool("IsHit",false);
    }
}
