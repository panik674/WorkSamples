 using System.Collections;
 using System.Collections.Generic;
 using UnityEngine;
 
 public class MusicChange2 : MonoBehaviour
 {
     public AudioSource currentSong;
     public AudioSource newSong;
     
     void OnCollisionEnter2D(Collision2D col)
     {
        if(col.gameObject.tag == "BossGround"){
        if(currentSong.isPlaying){
            currentSong.Stop();
            newSong.Play();
            }
            

         
     }
 }
 }