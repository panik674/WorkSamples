using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;

public class warriorAI : MonoBehaviour
{
    public float attackCooldown;
    public int damage;
    private float cooldownTimer = Mathf.Infinity;
    public LayerMask playerLayer;
    public BoxCollider2D boxCollider;
    public float range;
    public float colliderDistance;
    public Animator animator;
    public PlayerHealth playerHealth;
    public AudioSource SoundEffect;
    
    

    private void Update(){
        cooldownTimer += Time.deltaTime;

        if(seePlayer()){
            if(cooldownTimer >= attackCooldown){
                cooldownTimer = 0;
                animator.SetTrigger("Attack");
                SoundEffect.Play();
            }
        }
    }

    private bool seePlayer(){

        
        RaycastHit2D hit = Physics2D.BoxCast(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance, new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y, boxCollider.bounds.size.z), 0, Vector2.left, 0, playerLayer);
        
        if(hit.collider != null){
            playerHealth = hit.transform.GetComponent<PlayerHealth>();
        }
        
        return hit.collider != null && hit.collider.tag == "Player";
    
        
    }
    
    private void OnDrawGizmosSelected(){
        Gizmos.DrawWireCube(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance, new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y, boxCollider.bounds.size.z));
    }

    public void DamagePlayer(){
        if (playerHealth != null){
        playerHealth.TakeDamage(damage);
        }
    }
    }
