using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedAI : MonoBehaviour
{

    public float attackCooldown;
    public int damage;
    private float cooldownTimer = Mathf.Infinity;
    public LayerMask playerLayer;
    public BoxCollider2D boxCollider;
    public float range;
    public float colliderDistance;
    public Animator animator;
    public PlayerHealth playerHealth;
    public Transform firePoint;
    public FireBall fireball;
    public float projectileSpeed;
    public AudioSource SoundEffect;
    
    

    private void Update(){
        cooldownTimer += Time.deltaTime;

        if(seePlayer()){
            if(cooldownTimer >= attackCooldown){
                cooldownTimer = 0;
                animator.SetTrigger("Shoot");
                SoundEffect.Play();
            }
        }
    }

    private bool seePlayer(){
        
        RaycastHit2D hit = Physics2D.BoxCast(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance, new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y, boxCollider.bounds.size.z), 0, Vector2.left, 0, playerLayer);
        
        return hit.collider != null && hit.collider.tag == "Player";

    
        
    }
    
    private void OnDrawGizmosSelected(){
        Gizmos.DrawWireCube(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance, new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y, boxCollider.bounds.size.z));
    }

    void rangedAttack(){
        fireball.setTag("Player");
        fireball.setSpeed(projectileSpeed);
        Instantiate(fireball, firePoint.position, firePoint.rotation); 

    }

    public void DamagePlayer(){
        if (playerHealth != null){
        playerHealth.TakeDamage(damage);
        }
    }
}
