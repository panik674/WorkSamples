using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EnemyHealth : MonoBehaviour
{
    public Animator animator;
    public int health;
    public Transform transform;
    public PlayerMana playerMana;
    public TextMeshProUGUI text;
    public ManaPickup mana;
    public Animator playerAnimator;
    public bool isBoss;
    public Image tutorial;
    public Sprite image;
    public AudioSource icyCave;
    public AudioSource decisiveBattle;
    public AudioSource finalFantasy;
    public AudioSource manaSound;
    public AudioSource deathSound;
    
    public void TakeDamage(int dmg)
    {
        health -= dmg;
        if(health > 0){
        animator.SetTrigger("Hit");
        }
    
        if(health <= 0 ){
            animator.SetTrigger("Die");
            deathSound.Play();
        }
        }
    
    public void die(){
        if(!isBoss){
        Destroy(gameObject);
        mana.setPlayerMana(playerMana);
        mana.setText(text);
        mana.setPlayerAnimator(playerAnimator);
        mana.setSound(manaSound);
        Instantiate(mana, transform.position, transform.rotation);
        }
        else{
            Destroy(gameObject);
            tutorial.sprite = image;
            tutorial.enabled = true;
            Time.timeScale = 0;
            icyCave.Stop();
            decisiveBattle.Stop();
            finalFantasy.Play();
            
        }
        
    }
}
