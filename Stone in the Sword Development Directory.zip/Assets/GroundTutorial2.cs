using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GroundTutorial2 : MonoBehaviour{

public Image tutorial;
public Sprite image;
public bool tutorialShown = false;
public string tag;

void Start(){
    tutorial.enabled = false;
}



    void OnCollisionEnter2D(Collision2D col){
        if(col.gameObject.tag == "Player" && gameObject.tag == tag && !tutorialShown ){
            tutorial.sprite = image;
            tutorial.enabled = true;
            tutorialShown = true;
            Time.timeScale = 0;
        }
    }

}