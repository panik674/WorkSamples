using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ManaPickup : MonoBehaviour
{
    public PlayerMana PlayerMana;
    public PlayerMovement playerMovement;
    public TextMeshProUGUI text;
    public Animator animator;
    public int mana;
    public AudioSource SoundEffect;

    public void setPlayerMana(PlayerMana pm){
        PlayerMana = pm;
    }

    public void setText(TextMeshProUGUI txt){
        text = txt;
    }

    public void setPlayerAnimator(Animator anim){
        animator=anim;
    }

    public void setSound(AudioSource sound){
        SoundEffect = sound;
    }



    private void OnTriggerEnter2D(Collider2D collision){
        if(collision.tag == "Player"){
        PlayerMana.mana += mana;
        if(PlayerMana.mana > 100){
            PlayerMana.mana = 100;
        }
        text.text = PlayerMana.mana.ToString() + "/100";
        SoundEffect.Play();
        Destroy(gameObject);
        
        
        }
        
    }
}
