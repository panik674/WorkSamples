using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class heartChange : MonoBehaviour
{
    public PlayerHealth playerHealth;
    public int health;
    public Image heart;
    public Sprite emptyHeart;
    public Sprite fullHeart;
    public AudioSource music;
    public AudioSource bossMusic;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(playerHealth.health >= health){
            heart.sprite = fullHeart;
            music.pitch = (float)playerHealth.health / 5;
            bossMusic.pitch = (float)playerHealth.health / 5;
        }
        else{
            heart.sprite = emptyHeart;
            music.pitch = (float)playerHealth.health / 5;
            bossMusic.pitch = (float)playerHealth.health / 5;
        }

        
    }

        
    }

