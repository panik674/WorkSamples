using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerShoot : MonoBehaviour
{
    public Animator animator;
    public Transform firePoint;
    public FireBall fireball;
    public PlayerBreath breath;
    public TextMeshProUGUI breathText;
    public AudioSource SoundEffect;
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.X) && animator.GetBool("IsAttacking") == false && animator.GetBool("IsCharging") == false && animator.GetBool("IsJumping") == false && animator.GetBool("IsFalling") == false){
            animator.SetBool("IsShooting",true);
            }
            
    }
    

    void StopShooting(){
        animator.SetBool("IsShooting",false);
    }

    void Shoot(){
        if(breath.dragonsBreath > 0){
                SoundEffect.Play();
                breath.dragonsBreath -= 1;
                breathText.text = "Dragon's Breath: " + breath.dragonsBreath.ToString();
                fireball.setTag("Enemy");
                fireball.setSpeed(20f);
                Instantiate(fireball, firePoint.position, firePoint.rotation);
        }
        
    }

}

    

