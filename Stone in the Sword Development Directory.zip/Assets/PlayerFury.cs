using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerFury : MonoBehaviour
{

    public int dragonsFury;
    
    public void increaseFury(int amount){
        dragonsFury+=amount;
    }
}
