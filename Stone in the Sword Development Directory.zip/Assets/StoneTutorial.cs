using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StoneTutorial : MonoBehaviour{

public Image tutorial;
public Sprite image;

void Start(){
    tutorial.enabled = false;
}


    private void OnTriggerEnter2D(Collider2D collision){
        if(collision.tag == "Player"){
            tutorial.sprite = image;
            tutorial.enabled = true;
            Time.timeScale = 0;
        }
    }

}
