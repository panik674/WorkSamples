using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    public PlayerController controller;
    public Animator animator;
    public Rigidbody2D rigidbody;
    public AudioSource SoundEffect;
    public bool IsJumping;

    public float movementSpeed = 40f;
    
    float horizontalMovement = 0f;

    bool jump = false;

    // Update is called once per frame
    void Update()
    {
     horizontalMovement = Input.GetAxisRaw("Horizontal") * movementSpeed;

     animator.SetFloat("Speed", Mathf.Abs(horizontalMovement));
     
     if (Input.GetButtonDown("Jump")){
        if(!IsJumping){
            SoundEffect.Play();
        }
        IsJumping = true;
        jump = true;
        animator.SetBool("IsJumping", true);
        
            
        
     }

     if(rigidbody.velocity.y < 0){
        animator.SetBool("IsFalling", true);
     }   
    }

    public void OnLanding(){
        animator.SetBool("IsJumping", false);
        animator.SetBool("IsFalling", false);
        IsJumping = false;
    }

    void FixedUpdate ()
    {
        controller.Move(horizontalMovement * Time.fixedDeltaTime, false, jump);
        jump = false;
    }
}
