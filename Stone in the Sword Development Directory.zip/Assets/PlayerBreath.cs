using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBreath : MonoBehaviour
{
    public int dragonsBreath;

    public void increaseBreath(int amount){
        dragonsBreath+=amount;
    }
}
