using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ManaUpdate : MonoBehaviour
{
    public PlayerMana playerMana;
    public TextMeshPro text;
    

    
    void Update()
    {
        text.text = playerMana.mana.ToString() + "/100";
    }
}
