using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedPatrol : MonoBehaviour
{
    
    public Transform leftEdge;
    public Transform rightEdge;

    public Transform enemy;

    public float speed;

    public Animator animator;

    private Vector3 initScale;

    private bool movingLeft;

    public Transform firePoint;

    private void Awake(){
        if (enemy != null){
        initScale = enemy.localScale;
        }
    }

    private void Start(){
        movingLeft = true;
        

    }
    private void Update(){
        if(enemy != null){
        if(movingLeft){
            firePoint.rotation = Quaternion.Euler(enemy.rotation.x,-180,enemy.rotation.z);
            if(enemy.position.x >= leftEdge.position.x){
                MoveInDirection(-1);
            }
            else{
                DirectionChange();
            }
        }
        else{
            firePoint.rotation = Quaternion.Euler(enemy.rotation.x,0,enemy.rotation.z);
            if(enemy.position.x <= rightEdge.position.x){
                MoveInDirection(1);
            }
            else{
                DirectionChange();
            }
        }
        }
    }
    

    private void DirectionChange(){
        movingLeft = !movingLeft;
    }

    private void MoveInDirection(int direction){
        if(enemy != null){
        animator.SetBool("IsMoving", true);
        enemy.localScale = new Vector3(Mathf.Abs(initScale.x) * (-direction), initScale.y, initScale.z);
        enemy.position = new Vector3(enemy.position.x + Time.deltaTime * direction * speed, enemy.position.y, enemy.position.z);
        }
    }
    
}
